'use client';
// components/admin/Sidebar.tsx — Locale-aware admin sidebar
import Link from 'next/link';
import { usePathname, useParams } from 'next/navigation';
import { cn } from '@auto-bazaar-pro/utils';
import {
  LayoutDashboard, Users, Car, ListChecks, Settings,
  BarChart3, ShieldCheck, ChevronRight,
} from 'lucide-react';

export function AdminSidebar({ className }: { className?: string }) {
  const pathname = usePathname();
  const params = useParams();
  const locale = Array.isArray(params.locale) ? params.locale[0] : (params.locale ?? 'ku');

  const items = [
    { href: `/${locale}/admin`,           label: 'Overview',   icon: LayoutDashboard },
    { href: `/${locale}/admin/users`,     label: 'Users',      icon: Users           },
    { href: `/${locale}/admin/listings`,  label: 'Listings',   icon: Car             },
    { href: `/${locale}/admin/reports`,   label: 'Reports',    icon: BarChart3       },
    { href: `/${locale}/admin/moderation`,label: 'Moderation', icon: ShieldCheck     },
    { href: `/${locale}/admin/settings`,  label: 'Settings',   icon: Settings        },
  ];

  return (
    <aside className={cn('relative flex flex-col min-h-full bg-white dark:bg-[#080f1c] border-e border-slate-100 dark:border-white/[0.07] p-3', className)}>
      <div className="absolute inset-x-0 top-0 h-[2px] gold-line" />
      <div className="px-3 pt-6 pb-4 mb-2">
        <Link href={`/${locale}/admin`} className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-[10px] flex items-center justify-center"
               style={{ background: 'linear-gradient(135deg,#c9a84c,#9e6e1e)' }}>
            <ShieldCheck className="w-4 h-4 text-white" aria-hidden />
          </div>
          <div>
            <p className="text-[.82rem] font-bold text-slate-900 dark:text-white tracking-tight">
              AutoBazaar<span className="text-[#c9a84c]">Pro</span>
            </p>
            <p className="text-[10px] text-slate-400 dark:text-white/30">Admin</p>
          </div>
        </Link>
      </div>
      <nav className="flex-1 space-y-0.5">
        {items.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== `/${locale}/admin` && pathname.startsWith(href));
          return (
            <Link key={href} href={href} aria-current={active ? 'page' : undefined}
              className={cn('group flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
                active ? 'bg-[#c9a84c]/[0.12] text-[#c9a84c]' : 'text-slate-600 dark:text-white/50 hover:bg-slate-50 dark:hover:bg-white/[0.06] hover:text-slate-900 dark:hover:text-white')}>
              <span className="flex items-center gap-2.5">
                <Icon className={cn('w-4 h-4', active ? 'text-[#c9a84c]' : 'text-slate-400 dark:text-white/30')} aria-hidden />
                {label}
              </span>
              <ChevronRight className={cn('w-3 h-3 transition-all', active ? 'text-[#c9a84c] opacity-100' : 'opacity-0 group-hover:opacity-60')} aria-hidden />
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
